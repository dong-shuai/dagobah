Changelog
==============

0.3.3 (2012-09-29)
------------------
- proper packaging

