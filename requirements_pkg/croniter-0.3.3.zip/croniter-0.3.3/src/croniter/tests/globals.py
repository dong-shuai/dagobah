#!/usr/bin/env python
# -*- coding: utf-8 -*-
__docformat__ = 'restructuredtext en'

from pprint import pprint
from copy import deepcopy as dc


# vim:set et sts=4 ts=4 tw=80:
