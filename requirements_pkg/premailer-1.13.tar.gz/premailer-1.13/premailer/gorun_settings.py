DIRECTORIES = (
    ('.',
    # 'nosetests -v premailer.test_premailer -m test_parse_style_rules'
     'nosetests -v premailer.test_premailer'
    # 'nosetests -v premailer.test_premailer -m test_merge_styles',
    ),
)
